package com.example.consultorio.config;

import com.example.consultorio.entities.Usuario;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;


@Component
public class DataInitializer {

    @Autowired
    private PasswordEncoder passwordEncoder;

    private String correoAdminSemilla = "admin@gmail.com";

    private String claveAdminSemilla = "1234";

    //@Override
    //@Transactional
//    public void run(String... args) {
//        boolean yaExisteAdmin = usuarioRepository.existsByRolAndEliminadoFalse(Rol.ADMIN);
//        if (yaExisteAdmin) {
//            return;
//        }
//
//        Usuario admin = new Usuario();
//        admin.setCorreo(correoAdminSemilla);
//        admin.setClave(passwordEncoder.encode(claveAdminSemilla));
//        admin.setEliminado(false);
//        usuarioRepository.save(admin);
//
//    }
}
