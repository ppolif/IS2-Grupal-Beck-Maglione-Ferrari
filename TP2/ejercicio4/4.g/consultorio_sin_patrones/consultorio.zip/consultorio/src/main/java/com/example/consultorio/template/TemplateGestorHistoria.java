package com.example.consultorio.template;

import com.example.consultorio.entities.DetalleHistoriaClinica;
import com.example.consultorio.entities.HistoriaClinica;
import com.example.consultorio.entities.Paciente;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

public abstract class TemplateGestorHistoria {
    @Autowired
    protected HttpSession session;

    //plantilla crear
    public final void ejecutarRegistro(String idPaciente, DetalleHistoriaClinica primerDetalle) {
        validarSesion();

        Paciente paciente = obtenerPacienteActivo(idPaciente);

        verificarHistoriaInexistente(paciente);

        HistoriaClinica nuevaHistoria = inicializarHistoria(paciente);
        agregarNuevoDetalle(nuevaHistoria, primerDetalle);

        persistirHistoria(nuevaHistoria);
    }

    //plantilla modificar
    public final void ejecutarModificacion(String idPaciente, List<DetalleHistoriaClinica> nuevosDetalles) {
        validarSesion();
        Paciente paciente = obtenerPacienteActivo(idPaciente);
        HistoriaClinica historia = obtenerHistoriaDelPaciente(paciente);
        verificarHistoriaActiva(historia);

        // Solo nos encargamos de agregar la nueva información
        if (nuevosDetalles != null) {
            for (DetalleHistoriaClinica detalle : nuevosDetalles) {
                agregarNuevoDetalle(historia, detalle);
            }
        }
        actualizarHistoria(historia);
    }

    public final void ejecutarBajaDetalles(String idPaciente, List<String> idsDetallesAEliminar) {
        validarSesion();
        Paciente paciente = obtenerPacienteActivo(idPaciente);
        HistoriaClinica historia = obtenerHistoriaDelPaciente(paciente);
        verificarHistoriaActiva(historia);

        if (idsDetallesAEliminar != null && !idsDetallesAEliminar.isEmpty()) {
            marcarDetallesComoEliminados(historia, idsDetallesAEliminar);
        }

        actualizarHistoria(historia);
        System.out.println("Detalles de la Historia Clínica dados de baja con éxito.");
    }



    //
    protected void validarSesion() {
        Object usuario = session.getAttribute("usuariosession");

        if (usuario == null) {
            throw new RuntimeException("Acceso denegado: Debe iniciar sesión para realizar esta operación.");
        }
    }

    //metodos a sobre escribir
    protected abstract Paciente obtenerPacienteActivo(String idPaciente);
    protected abstract void verificarHistoriaInexistente(Paciente paciente);
    protected abstract HistoriaClinica inicializarHistoria(Paciente paciente);
    protected abstract void agregarNuevoDetalle(HistoriaClinica historia, DetalleHistoriaClinica detalle);
    protected abstract void persistirHistoria(HistoriaClinica historia);

    protected abstract HistoriaClinica obtenerHistoriaDelPaciente(Paciente paciente);
    protected abstract void eliminarDetalles(HistoriaClinica historia, List<String> idsAEliminar);
    protected abstract void actualizarHistoria(HistoriaClinica historia);
}
}
