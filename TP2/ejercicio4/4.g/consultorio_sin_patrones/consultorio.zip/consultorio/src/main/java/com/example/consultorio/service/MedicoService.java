package com.example.consultorio.service;

import com.example.consultorio.entities.Medico;
import com.example.consultorio.template.TemplateCrud;
import org.springframework.stereotype.Service;

@Service
public class MedicoService extends TemplateCrud<Medico> {
}
