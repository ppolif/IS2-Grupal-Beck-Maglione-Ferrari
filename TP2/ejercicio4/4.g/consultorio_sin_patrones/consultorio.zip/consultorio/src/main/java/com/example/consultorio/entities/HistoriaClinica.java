package com.example.consultorio.entities;

import jakarta.persistence.*;
import lombok.Data;

import java.util.List;

@Entity
@Data
public class HistoriaClinica{
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private String id;

    @ManyToOne
    private Paciente paciente;

    @ManyToOne
    private Usuario usuario;

    private boolean eliminado;

}
