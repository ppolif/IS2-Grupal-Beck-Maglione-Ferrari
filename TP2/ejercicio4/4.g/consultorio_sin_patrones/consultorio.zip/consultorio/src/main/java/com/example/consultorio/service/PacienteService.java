package com.example.consultorio.service;

import com.example.consultorio.entities.Paciente;
import com.example.consultorio.template.TemplateCrud;
import org.springframework.stereotype.Service;

@Service
public class PacienteService extends TemplateCrud<Paciente> {
}
